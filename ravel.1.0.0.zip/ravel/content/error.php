<article class="entry error">

	<header class="entry-header">
		<h1 class="entry-title"><?php _e( 'Error', 'ravel' ); ?></h1>
	</header><!-- .entry-header -->

	<div <?php hybrid_attr( 'entry-content' ); ?>>
		<?php get_search_form(); ?>
	</div><!-- .entry-content -->

</article><!-- .entry -->